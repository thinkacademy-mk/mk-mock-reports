export const LEVELS = ['1-2', '3-4', '5-6'];
const TOKEN = /^[a-f0-9]{32}$/;
const STUDENT_NUMBER = /^\d{12}$/;
export const isStudentNumber = value => typeof value === 'string' && STUDENT_NUMBER.test(value);
export const isReportToken = value => typeof value === 'string' && TOKEN.test(value);

export async function reportTokenFor(studentNumber, cryptoProvider = globalThis.crypto) {
  if (!isStudentNumber(studentNumber)) throw new TypeError('Invalid Student Number');
  if (!cryptoProvider?.subtle) throw new Error('Secure browser required');
  const digest = await cryptoProvider.subtle.digest('SHA-256', new TextEncoder().encode(`mk-mock1:${studentNumber}`));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('').slice(0, 32);
}

const REPORT_KEYS = ['level', 'score', 'maximum', 'rank', 'percentile', 'cohortSize', 'htmlPath', 'pdfPath'];
export function validateReport(report, token) {
  if (!report || typeof report !== 'object' || Array.isArray(report) ||
      Object.keys(report).length !== REPORT_KEYS.length ||
      Object.keys(report).some(key => !REPORT_KEYS.includes(key)) || !LEVELS.includes(report.level)) throw new TypeError('Invalid report');
  const maximum = report.level === '5-6' ? 120 : 96;
  if (report.maximum !== maximum || !Number.isInteger(report.score) || report.score < 0 || report.score > maximum ||
      !Number.isInteger(report.cohortSize) || report.cohortSize < 1 ||
      !Number.isInteger(report.rank) || report.rank < 1 || report.rank > report.cohortSize ||
      typeof report.percentile !== 'number' || !Number.isFinite(report.percentile) || report.percentile < 0 || report.percentile > 100 ||
      !isReportToken(token) || report.htmlPath !== `${token}-${report.level}.html` ||
      report.pdfPath !== `pdfs/${token}-${report.level}.pdf`) throw new TypeError('Invalid score or report path');
  return report;
}

export async function validateStudentRecord(payload, { studentNumber, token } = {}) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload) ||
      Object.keys(payload).length !== 4 || Object.keys(payload).some(key => !['schemaVersion', 'reportType', 'studentNumber', 'reports'].includes(key)) ||
      payload.schemaVersion !== 3 || payload.reportType !== 'mk-mock-report' || !isStudentNumber(payload.studentNumber) ||
      !Array.isArray(payload.reports) || !payload.reports.length || payload.reports.length > LEVELS.length ||
      (studentNumber !== undefined && payload.studentNumber !== studentNumber)) throw new TypeError('Invalid student record');
  const computed = await reportTokenFor(payload.studentNumber);
  if (token !== undefined && (!isReportToken(token) || token !== computed)) throw new TypeError('Report identity mismatch');
  const levels = new Set();
  for (const report of payload.reports) {
    validateReport(report, computed);
    if (levels.has(report.level)) throw new TypeError('Duplicate report level');
    levels.add(report.level);
  }
  return payload;
}

export function reportDestination(report, token, siteRoot) {
  if (!LEVELS.includes(report?.level) || !isReportToken(token)) throw new TypeError('Invalid report destination');
  const destination = new URL('report/', siteRoot);
  destination.searchParams.set('report', token);
  destination.searchParams.set('level', report.level);
  return destination;
}
