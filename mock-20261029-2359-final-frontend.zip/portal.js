import { isStudentNumber, reportTokenFor, validateStudentRecord, reportDestination } from './lookup-model.mjs?v=mock-20261029-2359-final';

const siteRoot = new URL('./', import.meta.url);
const form = document.getElementById('lookup-form');
const field = document.getElementById('student-number');
const button = document.getElementById('lookup-submit');
const buttonLabel = button.querySelector('span');
const message = document.getElementById('lookup-message');
const picker = document.getElementById('level-picker');
const options = document.getElementById('level-options');
let activeController = null;
let requestSerial = 0;
let pending = false;

function setMessage(text, state = '') {
  message.textContent = text;
  message.className = `lookup-message${state ? ` ${state}` : ''}`;
}

function setPending(value) {
  pending = value;
  button.disabled = value;
  field.readOnly = value;
  buttonLabel.textContent = value ? 'Finding your report…' : 'View my report';
  if (value) button.setAttribute('aria-busy', 'true');
  else button.removeAttribute('aria-busy');
}

function chooseReport(record, token) {
  options.replaceChildren();
  for (const report of [...record.reports].sort((a, b) => a.level.localeCompare(b.level))) {
    const link = document.createElement('a');
    link.className = 'level-option';
    link.href = reportDestination(report, token, siteRoot).href;
    const title = document.createElement('strong');
    title.textContent = `Level ${report.level.replace('-', '–')}`;
    const score = document.createElement('span');
    score.textContent = `${report.score} / ${report.maximum}`;
    const arrow = document.createElement('span');
    arrow.textContent = '→';
    arrow.setAttribute('aria-hidden', 'true');
    link.append(title, score, arrow);
    options.append(link);
  }
  picker.hidden = false;
  options.querySelector('a')?.focus();
}

async function lookup() {
  if (pending) return;
  picker.hidden = true;
  field.removeAttribute('aria-invalid');
  const studentNumber = field.value.trim();
  if (!isStudentNumber(studentNumber)) {
    field.setAttribute('aria-invalid', 'true');
    setMessage('Enter a complete 12-digit Student Number using digits 0–9.', 'error');
    field.focus();
    return;
  }
  if (!globalThis.crypto?.subtle) {
    setMessage('Open this page using HTTPS in an up-to-date browser, then try again.', 'error');
    return;
  }
  const serial = ++requestSerial;
  const controller = new AbortController();
  activeController = controller;
  const timeout = setTimeout(() => controller.abort(), 12000);
  setPending(true);
  setMessage('');
  try {
    const token = await reportTokenFor(studentNumber);
    if (serial !== requestSerial) return;
    const response = await fetch(new URL(`reports/${token}.json`, siteRoot), {
      credentials: 'same-origin', cache: 'no-store', signal: controller.signal
    });
    if (serial !== requestSerial) return;
    if (response.status === 404) {
      setMessage('No report found. Check the Student Number from My Family and try again.', 'error');
      return;
    }
    if (!response.ok) throw new Error('Report unavailable');
    const record = await validateStudentRecord(await response.json(), { studentNumber, token });
    if (serial !== requestSerial) return;
    if (record.reports.length === 1) {
      setMessage('Opening your report…', 'success');
      window.location.assign(reportDestination(record.reports[0], token, siteRoot).href);
    } else {
      setMessage('Your reports are ready. Choose a level below.', 'success');
      chooseReport(record, token);
    }
  } catch {
    if (serial === requestSerial) setMessage('We could not load your report. Check your connection and try again.', 'error');
  } finally {
    clearTimeout(timeout);
    if (serial === requestSerial) {
      activeController = null;
      setPending(false);
    }
  }
}

form.addEventListener('submit', event => { event.preventDefault(); void lookup(); });
field.addEventListener('input', () => { field.removeAttribute('aria-invalid'); setMessage(''); picker.hidden = true; });
window.addEventListener('pagehide', () => { requestSerial += 1; activeController?.abort(); activeController = null; });
window.addEventListener('pageshow', event => {
  if (!event.persisted) return;
  requestSerial += 1;
  activeController?.abort();
  activeController = null;
  setPending(false);
  setMessage('');
});
setPending(false);
