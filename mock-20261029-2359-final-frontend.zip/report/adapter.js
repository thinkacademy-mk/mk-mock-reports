import { LEVELS, isReportToken, validateStudentRecord } from '../lookup-model.mjs?v=mock-20261029-2359-final';
const siteRoot = new URL('../', import.meta.url);
const status = document.getElementById('report-status');
const params = new URL(window.location.href).searchParams;
const token = params.get('report');
const level = params.get('level');
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 12000);
try {
  if (!isReportToken(token) || !LEVELS.includes(level)) throw new Error('Invalid report link');
  const response = await fetch(new URL(`reports/${token}.json`, siteRoot), {
    credentials: 'same-origin', cache: 'no-store', signal: controller.signal
  });
  if (!response.ok) throw new Error('Report unavailable');
  const record = await validateStudentRecord(await response.json(), { token });
  const report = record.reports.find(item => item.level === level);
  if (!report) throw new Error('Level not available');
  const destination = new URL(report.htmlPath, siteRoot);
  if (destination.origin !== siteRoot.origin || !destination.pathname.startsWith(siteRoot.pathname)) throw new Error('Invalid report path');
  window.location.replace(destination.href);
} catch {
  status.textContent = 'We could not open this report. Return to report lookup and enter your Student Number again.';
} finally {
  clearTimeout(timeout);
}
