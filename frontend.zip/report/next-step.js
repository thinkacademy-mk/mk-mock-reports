import { nextStepTemplate } from './next-step-template.js';
import { renderPracticeModules } from './practice-priorities.js';
import { t, moduleName } from './i18n.js';
import { preparationGoal, buildGoalPlan } from './goal-plan.js';
import { goalText } from './goal-copy.js';

// Update the copy without removing adjacent icons, badges, or caption details.
function setOwnText(element, value) {
  if (!element) return;
  const textNodes = [...element.childNodes].filter(node => node.nodeType === 3);
  if (textNodes.length) {
    textNodes[0].textContent = value;
    textNodes.slice(1).forEach(node => { node.textContent = ''; });
  } else {
    element.append(document.createTextNode(value));
  }
}

function translateText(element, key, vars = {}, fallback) {
  if (!element) return '';
  const original = [...element.childNodes]
    .filter(node => node.nodeType === 3)
    .map(node => node.textContent).join('').trim();
  const writing = t(key, vars, fallback ?? original);
  setOwnText(element, writing);
  return writing;
}

function renderProgramLabels(root) {
  translateText(root.querySelector('#mk-support-course-title'), 'program.title');
  translateText(root.querySelector('.recommended-label'), 'program.recommended');
  root.querySelectorAll('.mix-label').forEach(label => {
    translateText(label, 'program.question-mix');
  });
  translateText(root.querySelector('.support-heading h3'), 'program.included-support');
  const highlights = [
    ['program.small-classes', {}],
    ['program.live-online', {}],
    ['program.all-english', {}],
    ['program.past-paper-research', { years: 15 }]
  ];
  root.querySelectorAll('.highlights li').forEach((item, index) => {
    const entry = highlights[index];
    if (entry) translateText(item, entry[0], entry[1]);
  });
  const services = [
    ['program.support.mock-tests', 5],
    ['program.support.past-paper', 10],
    ['program.support.daily-check-in', 405]
  ];
  root.querySelectorAll('.service h4').forEach((heading, index) => {
    const entry = services[index];
    if (entry) translateText(heading, entry[0], { count: entry[1] });
  });
  translateText(root.querySelector('.syllabus figcaption'), 'program.syllabus');
}

function renderRoadmapLabels(roadmap, goal) {
  translateText(roadmap.querySelector('#mk-support-roadmap-title'), 'roadmap.title');
  for (const lane of ['learn', 'assess', 'practice']) {
    translateText(roadmap.querySelector(`.lane.${lane} .lane-label`), `roadmap.${lane}`);
  }
  const weeklyTitle = translateText(roadmap.querySelector('.learn-overview > strong'), 'roadmap.weekly-lessons', { count: 24 });
  const courseModules = ['geometry', 'numbers', 'number-theory', 'word', 'counting', 'logic'];
  const names = [...roadmap.querySelectorAll('.learn-modules > span')].map((label, index) => {
    const name = moduleName(courseModules[index], label.textContent);
    setOwnText(label, name);
    return name;
  });
  roadmap.querySelector('.learn-overview').setAttribute('aria-label', `${goal.course}: ${weeklyTitle}; ${names.join(', ')}`);
  roadmap.querySelectorAll('.mock > strong').forEach((label, index) => {
    translateText(label, 'roadmap.mock', { number: index + 1 });
  });
  const completed = roadmap.querySelector('.done-label');
  if (completed) completed.setAttribute('aria-label', t('nextstep.complete', {}, 'Complete'));
  translateText(roadmap.querySelector('.paper-bar'), 'roadmap.past-paper-review', { months: 'Jan–Mar', count: 10 });
  translateText(roadmap.querySelector('.daily-practice-heading'), 'roadmap.daily-check-in');
  const practiceModules = ['geometry', 'numbers-patterns', 'word', 'logic'];
  roadmap.querySelectorAll('.practice-module').forEach((label, index) => {
    setOwnText(label, moduleName(practiceModules[index], label.textContent));
  });
}

export function level34Goal(score) {
  return preparationGoal(3, score);
}

function renderGoalProgress(root, goal) {
  const section = root.querySelector('.next-step-section');
  const header = section.querySelector('.next-step-header');
  const target = section.querySelector('.mission-target');
  const progress = section.querySelector('.goal-progress-list');
  const text = (tag, className, content) => {
    const element = document.createElement(tag);
    element.className = className;
    element.textContent = content;
    return element;
  };
  section.classList.add('goal-single-column');
  section.dataset.score = String(goal.score);
  section.dataset.goal = goal.title;
  translateText(section.querySelector('#mk-next-step-title'), 'nextstep.title');

  const targetCopy = target.querySelector('.target-copy');
  targetCopy.replaceChildren(
    text('span', 'goal-step-label', t('nextstep.recommended-goal', {}, 'Recommended goal')),
    text('strong', '', goal.title),
    text('p', 'target-profile-description', t('nextstep.target-profile', {
      three: goal.profileTargets[0], four: goal.profileTargets[1], five: goal.profileTargets[2], total: goal.total
    }, `Target profile: 3-point ${goal.profileTargets[0]}/${goal.total} · 4-point ${goal.profileTargets[1]}/${goal.total} · 5-point ${goal.profileTargets[2]}/${goal.total}`))
  );
  target.querySelector('.current-result')?.remove();

  const overview = document.createElement('div');
  overview.className = 'goal-progress-overview';
  overview.append(
    text('p', 'goal-step-label', goalText('nextstep.distance-title')),
    text('strong', 'goal-points-gap', goal.pointsToGain
      ? goalText('nextstep.points-to-go', { points_to_gain: goal.pointsToGain })
      : goalText('nextstep.profile-achieved')),
    text('p', 'goal-profile-score', t('nextstep.selected-target-score', {
      goal: goal.title, profile_score: goal.profileScore, maximum: goal.maximum
    }, `${goal.title} target: ${goal.profileScore}/${goal.maximum}`))
  );

  progress.querySelectorAll('.goal-progress-row').forEach((row, index) => {
    const current = goal.bands[index];
    const targetCount = goal.profileTargets[index];
    const remaining = goal.remaining[index];
    const pointLabel = translateText(row.querySelector('.goal-row-label h3'), 'nextstep.point-questions', { points: row.dataset.band });
    row.dataset.correct = String(current);
    row.dataset.target = String(targetCount);
    row.classList.toggle('is-complete', remaining === 0);
    row.querySelector('.goal-row-target').textContent = goalText('nextstep.target-count', { target: targetCount, total: goal.total });
    row.querySelector('.goal-row-label').append(text('span', 'goal-row-current',
      t('nextstep.current-count', { current, total: goal.total }, `Current: ${current}/${goal.total}`)));
    const status = remaining === 0
      ? `✓ ${t('nextstep.complete', {}, 'Complete')}`
      : t('nextstep.remaining-more', { remaining }, `${remaining} more to go`);
    const statusNode = row.querySelector('.goal-row-status');
    statusNode.replaceChildren(text('span', '', status));
    if (remaining) statusNode.append(text('small', '', goalText('nextstep.point-gain', { points: goal.gains[index] })));
    const meter = row.querySelector('.goal-cells');
    meter.style.setProperty('--target-count', String(targetCount));
    meter.setAttribute('aria-valuenow', String(Math.min(current, targetCount)));
    meter.setAttribute('aria-valuemax', String(targetCount));
    meter.setAttribute('aria-label', `${pointLabel}; Current: ${current}/${goal.total}; Target: ${targetCount}/${goal.total}; ${status}`);
    meter.replaceChildren(...Array.from({ length: targetCount }, (_, cellIndex) => {
      const cell = document.createElement('span');
      cell.className = cellIndex < current ? 'goal-cell filled' : 'goal-cell needed';
      return cell;
    }));
    row.querySelector('.goal-reference')?.remove();
  });

  let explanation = 'Your target profile is complete. Keep practising consistently and aim to repeat this result in your next mock.';
  if (goal.questionsToGain && goal.bands[0] === goal.total) {
    explanation = 'Your 3-point questions are already complete. The fastest path to your recommended goal is to ';
    if (goal.remaining[1] && goal.remaining[2]) explanation += `secure the remaining 4-point ${goal.remaining[1] === 1 ? 'question' : 'questions'}, then improve your 5-point accuracy.`;
    else if (goal.remaining[1]) explanation += 'secure the remaining 4-point questions while keeping your other results consistent.';
    else explanation += 'improve your 5-point accuracy while keeping your 3- and 4-point questions perfect.';
  } else if (goal.questionsToGain) {
    explanation = 'Secure the remaining 3-point questions, then work through the 4- and 5-point targets above.';
  }
  section.replaceChildren(header, target, overview, progress, text('p', 'goal-explanation', explanation));
}

function renderClosingCTA(root) {
  const section = document.createElement('section');
  section.className = 'closing-cta';
  section.setAttribute('aria-labelledby', 'mk-cta-title');
  const copy = document.createElement('div');
  copy.className = 'cta-copy';
  const title = document.createElement('h2');
  title.id = 'mk-cta-title';
  title.textContent = t('cta.free-trial-title', {}, 'Take the next step with Think Academy');
  const description = document.createElement('p');
  description.textContent = t('cta.free-trial-description', {}, 'Try a live class and find the right learning path for your child.');
  copy.append(title, description);
  const action = document.createElement('a');
  action.className = 'cta-button';
  action.href = 'https://www.thethinkacademy.com/link/l/GW5V';
  action.target = '_blank';
  action.rel = 'noopener noreferrer';
  const label = document.createElement('span');
  label.textContent = t('cta.book-free-trial', {}, 'Book a Free Trial');
  const arrow = document.createElement('span');
  arrow.textContent = '→';
  arrow.setAttribute('aria-hidden', 'true');
  action.append(label, arrow);
  section.append(copy, action);
  root.append(section);
}

function renderRecommendedCourse(root, goal, level) {
  const tracks = root.querySelector('.tracks');
  const cards = [...tracks.querySelectorAll('.track')];
  const label = tracks.querySelector('.recommended-label');
  const recommended = cards.find(card => card.querySelector('h3').textContent === goal.course);
  cards.forEach(card => card.classList.toggle('recommended', card === recommended));
  recommended.querySelector('.track-title').append(label);
  tracks.replaceChildren(recommended, ...cards.filter(card => card !== recommended));

  const syllabus = root.querySelector('.syllabus');
  if (level !== '3-4') { syllabus?.remove(); return; }
  syllabus.querySelector('figcaption span').textContent = `Level 3–4 · ${goal.course}`;
  const image = syllabus.querySelector('img');
  image.src = `materials/grade3-4-${goal.top5 ? 'top5' : 'top20'}-syllabus.jpg`;
  image.alt = `Original Think Academy Level 3–4 ${goal.course} curriculum, with the complete lesson outline, key topics, and skills.`;
  image.width = 1413;
  image.height = 795;
  image.loading = 'lazy';
  const preview = document.createElement('button');
  preview.type = 'button';
  preview.className = 'syllabus-preview';
  preview.dataset.materialSrc = image.getAttribute('src');
  preview.dataset.materialTitle = `Level 3–4 · ${goal.course} ${t('program.syllabus', {}, 'Course Syllabus')}`;
  preview.setAttribute('aria-label', `Open the full ${goal.course} course syllabus`);
  image.replaceWith(preview);
  preview.append(image);
}

export function renderNextStepsView({ host, score, bands, enrolled, audience = enrolled ? 'enrolled' : 'new', questions, wrongQuestionIds, studentName = '', grade = 3, level = '3-4' }) {
  const goal = buildGoalPlan({ grade, score, bands });
  host.innerHTML = nextStepTemplate;
  const root = host.querySelector('#mk-next-step-integrated');
  root.setAttribute('aria-label', `${studentName}’s Math Kangaroo next steps and preparation program`);
  root.querySelector('.next-step-section').dataset.level = level;
  renderGoalProgress(root, goal);
  const priorities = root.querySelector('.priority-section');
  const content = renderPracticeModules({ questions, wrongQuestionIds, enrolled: audience !== 'new', top5: goal.top5, includeCourseReferences: audience !== 'unknown' });
  priorities.querySelector('.practice-priority-content').innerHTML = content;
  priorities.hidden = !content;
  translateText(priorities.querySelector('h2'), audience === 'new' ? 'practice-plan.prospective-title' : 'practice-plan.enrolled-title', { student_name: studentName }, audience === 'new' ? `${studentName}’s Practice Plan` : 'Your Practice Priorities');
  if (audience !== 'new') {
    root.querySelector('.program-section').remove();
    root.querySelector('.roadmap-section').remove();
  } else {
    renderProgramLabels(root);
    const program = root.querySelector('.program-section');
    program.querySelector('.eyebrow').textContent = `Math Kangaroo · Level ${level.replace('-', '–')}`;
    renderRecommendedCourse(root, goal, level);
    const roadmap = root.querySelector('.roadmap-section');
    if (level === '3-4') {
      renderRoadmapLabels(roadmap, goal);
      program.querySelector('.tracks').after(roadmap);
      program.querySelector('.syllabus').before(priorities);
    } else {
      // Detailed lesson ranges, syllabus artwork and dates are verified only for Level 3–4.
      roadmap.remove();
      program.querySelector('.intro').textContent = 'Build the problem-solving methods behind Math Kangaroo questions in a small online class. Choose a learning path that matches your next goal.';
      program.querySelector('.shared-facts')?.remove();
      program.querySelectorAll('.mix-label, .mix, .ratio').forEach(node => node.remove());
      program.append(priorities);
    }
  }
  renderClosingCTA(root);
}
