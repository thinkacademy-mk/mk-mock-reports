const POINTS = [3, 4, 5];

// Reference scores and complete example profiles: supplied prep talk, pp. 27–31.
// The placement thresholds retain the prototype's existing class policy;
// they are separate from the talk's suggested preparation scores.
const CONFIG = {
  junior: { total: 8, maximum: 96, placement: 70, reference: [75, 90], fivePointTargets: [4, 7] },
  senior: { total: 10, maximum: 120, placement: 96, reference: [99, 114], fivePointTargets: [6, 9] }
};

export function preparationGoal(grade, score) {
  if (!Number.isInteger(grade) || grade < 1 || grade > 6) throw new RangeError('A grade from 1 to 6 is required.');
  const config = CONFIG[grade >= 5 ? 'senior' : 'junior'];
  const top5 = score >= config.placement;
  return {
    top5,
    title: top5 ? 'Top 5' : 'Top 20',
    course: top5 ? 'Top 5 Elite' : 'Top 20 Mastery',
    targets: [config.total, config.total, config.fivePointTargets[Number(top5)]],
    referenceScore: config.reference[Number(top5)],
    total: config.total,
    maximum: config.maximum,
    grade
  };
}

export function buildGoalPlan({ grade = 3, score, bands }) {
  const goal = preparationGoal(grade, score);
  if (!Array.isArray(bands) || bands.length !== 3 || bands.some(count => !Number.isInteger(count) || count < 0 || count > goal.total)) {
    throw new RangeError('Three correct-answer counts are required for this grade.');
  }
  const actualScore = bands.reduce((sum, count, index) => sum + count * POINTS[index], 0);
  if (actualScore !== score) throw new RangeError('The reported score must match the three point-value results.');
  const remaining = goal.targets.map((target, index) => Math.max(target - bands[index], 0));
  const gains = remaining.map((count, index) => count * POINTS[index]);
  // Keep answers already correct above a benchmark. The resulting score and
  // additional-question breakdown then describe the same personal milestone.
  const profileTargets = goal.targets.map((target, index) => Math.max(target, bands[index]));
  const profileScore = profileTargets.reduce((sum, count, index) => sum + count * POINTS[index], 0);
  const pointsToGain = gains.reduce((sum, points) => sum + points, 0);
  const questionsToGain = remaining.reduce((sum, count) => sum + count, 0);
  const metBands = goal.targets.map((target, index) => bands[index] >= target ? POINTS[index] : null).filter(Boolean);
  const perfect = score === goal.maximum;
  let whereState = 'building';
  if (perfect) whereState = 'perfect';
  else if (!questionsToGain) whereState = 'achieved';
  else if (!remaining[0] && !remaining[1]) whereState = 'foundation-secured';
  else if (bands[0] === goal.total && remaining[1] <= 1 && remaining[2]) whereState = 'strong-foundation';
  else if (metBands.length === 2) whereState = 'two-met';
  else if (metBands.length === 1) whereState = 'one-met';
  let nextState = 'foundation';
  if (perfect) nextState = 'perfect';
  else if (!questionsToGain) nextState = 'maintain';
  else if (gains[2] > gains[0] + gains[1]) nextState = 'five-point';
  else if (!remaining[0] && remaining[1] && !remaining[2]) nextState = 'four-point';
  else if (remaining[0] && !remaining[1] && !remaining[2]) nextState = 'three-point';
  return { ...goal, score, bands: [...bands], remaining, gains, profileTargets, profileScore, pointsToGain, questionsToGain, metBands, perfect, whereState, nextState };
}
