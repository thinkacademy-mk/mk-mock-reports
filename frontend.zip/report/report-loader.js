import { isReportToken, validateStudentRecord } from '../lookup-model.mjs';

export async function loadReport() {
  const status = document.getElementById('report-loading');
  const params = new URLSearchParams(location.search);
  const token = params.get('report');
  const level = params.get('level');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    if (!isReportToken(token)) throw new Error('Missing report');
    const response = await fetch(new URL(`../reports/${token}.json`, import.meta.url), {
      signal: controller.signal, credentials: 'same-origin', cache: 'no-store'
    });
    if (!response.ok) throw new Error('Report unavailable');
    const record = await validateStudentRecord(await response.json(), { token });
    const report = record.reports.find(item => item.level === level) ?? (!level && record.reports.length === 1 ? record.reports[0] : null);
    if (!report) throw new Error('Choose a level');
    status.hidden = true;
    document.getElementById('report').hidden = false;
    return { ...report, studentNumber: record.studentNumber, token, availableLevels: record.reports.map(item => item.level) };
  } catch {
    status.replaceChildren();
    const title = document.createElement('h1');
    title.textContent = 'Report unavailable';
    const description = document.createElement('p');
    description.textContent = 'Return to the lookup page to find your report and choose a level.';
    const link = document.createElement('a');
    link.href = '../';
    link.textContent = 'Back to report lookup';
    status.append(title, description, link);
    throw new Error('Mock report could not be loaded');
  } finally {
    clearTimeout(timer);
  }
}
