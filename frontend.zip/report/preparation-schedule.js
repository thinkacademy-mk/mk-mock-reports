export const weeklyLessons = [
  {
    "calendar_month": "Sep",
    "lesson": 1,
    "top20_module": "Geometry",
    "top5_module": "Geometry"
  },
  {
    "calendar_month": "Sep",
    "lesson": 2,
    "top20_module": "Geometry",
    "top5_module": "Geometry"
  },
  {
    "calendar_month": "Sep",
    "lesson": 3,
    "top20_module": "Geometry",
    "top5_module": "Geometry"
  },
  {
    "calendar_month": "Sep",
    "lesson": 4,
    "top20_module": "Geometry",
    "top5_module": "Geometry"
  },
  {
    "calendar_month": "Oct",
    "lesson": 5,
    "top20_module": "Geometry",
    "top5_module": "Geometry"
  },
  {
    "calendar_month": "Oct",
    "lesson": 6,
    "top20_module": "Numbers & Operations",
    "top5_module": "Numbers & Operations"
  },
  {
    "calendar_month": "Oct",
    "lesson": 7,
    "top20_module": "Numbers & Operations",
    "top5_module": "Numbers & Operations"
  },
  {
    "calendar_month": "Oct",
    "lesson": 8,
    "top20_module": "Numbers & Operations",
    "top5_module": "Numbers & Operations"
  },
  {
    "calendar_month": "Nov",
    "lesson": 9,
    "top20_module": "Number Theory",
    "top5_module": "Number Theory"
  },
  {
    "calendar_month": "Nov",
    "lesson": 10,
    "top20_module": "Word Problems",
    "top5_module": "Word Problems"
  },
  {
    "calendar_month": "Nov",
    "lesson": 11,
    "top20_module": "Word Problems",
    "top5_module": "Word Problems"
  },
  {
    "calendar_month": "Dec",
    "lesson": 12,
    "top20_module": "Word Problems",
    "top5_module": "Word Problems"
  },
  {
    "calendar_month": "Dec",
    "lesson": 13,
    "top20_module": "Word Problems",
    "top5_module": "Word Problems"
  },
  {
    "calendar_month": "Dec",
    "lesson": 14,
    "top20_module": "Word Problems",
    "top5_module": "Word Problems"
  },
  {
    "calendar_month": "Jan",
    "lesson": 15,
    "top20_module": "Word Problems",
    "top5_module": "Counting, Probability & Statistics"
  },
  {
    "calendar_month": "Jan",
    "lesson": 16,
    "top20_module": "Word Problems",
    "top5_module": "Counting, Probability & Statistics"
  },
  {
    "calendar_month": "Jan",
    "lesson": 17,
    "top20_module": "Counting, Probability & Statistics",
    "top5_module": "Logical Reasoning"
  },
  {
    "calendar_month": "Jan",
    "lesson": 18,
    "top20_module": "Counting, Probability & Statistics",
    "top5_module": "Logical Reasoning"
  },
  {
    "calendar_month": "Feb",
    "lesson": 19,
    "top20_module": "Counting, Probability & Statistics",
    "top5_module": "Logical Reasoning"
  },
  {
    "calendar_month": "Feb",
    "lesson": 20,
    "top20_module": "Logical Reasoning",
    "top5_module": "Logical Reasoning"
  },
  {
    "calendar_month": "Feb",
    "lesson": 21,
    "top20_module": "Logical Reasoning",
    "top5_module": "Logical Reasoning"
  },
  {
    "calendar_month": "Feb",
    "lesson": 22,
    "top20_module": "Logical Reasoning",
    "top5_module": "Logical Reasoning"
  },
  {
    "calendar_month": "Mar",
    "lesson": 23,
    "top20_module": "Logical Reasoning",
    "top5_module": "Logical Reasoning"
  },
  {
    "calendar_month": "Mar",
    "lesson": 24,
    "top20_module": "Logical Reasoning",
    "top5_module": "Logical Reasoning"
  }
];

export function renderWeeklyLessons(top5) {
  const months = ['Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
  const field = top5 ? 'top5_module' : 'top20_module';
  return months.map(month => `<div class="lesson-month" data-month="${month}"><ol aria-label="${month} lessons">${weeklyLessons.filter(week => week.calendar_month === month).map(week => `<li class="lesson-week" data-lesson="${week.lesson}"><span>Lesson ${week.lesson}</span><strong>${week[field].replaceAll('&', '&amp;')}</strong></li>`).join('')}</ol></div>`).join('');
}
