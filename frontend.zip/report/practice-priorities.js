import { t, moduleName, REPORT_LEVEL } from './i18n.js';

const MODULES = {
  geometry: { name: 'Geometry', lessons: { top5: '1–5', top20: '1–5' } },
  numbers: { name: 'Numbers & Operations', lessons: { top5: '6–8', top20: '6–8' } },
  word: { name: 'Word Problems', lessons: { top5: '10–14', top20: '10–16' } },
  logic: { name: 'Logical Reasoning', lessons: { top5: '17–24', top20: '20–24' } },
  'number-theory': { name: 'Number Theory' },
  counting: { name: 'Counting, Probability & Statistics' }
};

const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[character]));

/** Select actual missed modules; do not infer errors from the total score. */
export function selectPracticeModules(questions = [], wrongQuestionIds = []) {
  const wrongIds = new Set(Array.from(wrongQuestionIds ?? [], id => String(id)));
  const groups = new Map();
  const moduleOrder = Object.keys(MODULES);

  for (const question of questions) {
    const key = String(question.module ?? '');
    if (!Object.hasOwn(MODULES, key)) continue;
    if (!groups.has(key)) {
      groups.set(key, {
        key,
        name: moduleName(key, MODULES[key].name),
        questions: [],
        missedQuestions: [],
        assessedCount: 0,
        missedCount: 0,
        errorRate: 0,
        lostPoints: 0,
        order: moduleOrder.indexOf(key)
      });
    }
    const group = groups.get(key);
    group.questions.push(question);
    group.assessedCount += 1;
    if (wrongIds.has(String(question.id))) {
      group.missedQuestions.push(question);
      group.missedCount += 1;
      const points = Number(question.points);
      group.lostPoints += Number.isFinite(points) ? points : 0;
    }
  }

  return [...groups.values()]
    .filter(group => group.missedCount > 0)
    .map(group => ({ ...group, errorRate: group.missedCount / group.assessedCount }))
    .sort((a, b) => b.errorRate - a.errorRate || b.lostPoints - a.lostPoints || a.order - b.order)
    .slice(0, 4)
    .map(({ order, ...group }) => group);
}

const normalizeCopy = value => String(value ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();

function groupMissedTopics(questions) {
  const topics = new Map();
  for (const question of questions) {
    const key = normalizeCopy(question.topic) || `question-${question.id}`;
    if (!topics.has(key)) topics.set(key, { topic: question.topic ?? '', questionIds: [], guidance: [], guidanceKeys: new Set() });
    const group = topics.get(key);
    if (!group.questionIds.some(id => String(id) === String(question.id))) group.questionIds.push(question.id);
    const guidance = String(question.guidance ?? '').trim();
    const guidanceKey = normalizeCopy(guidance);
    if (guidance && !group.guidanceKeys.has(guidanceKey)) {
      group.guidance.push(guidance);
      group.guidanceKeys.add(guidanceKey);
    }
  }
  return [...topics.values()];
}

const questionReferences = questionIds => questionIds.map(id => `Q${escapeHTML(id)}`).join(' · ');

function courseReferences(module, enrolled, top5) {
  const groups = new Map();
  for (const question of module.missedQuestions) {
    if (String(question.level ?? REPORT_LEVEL).replace(/^lv/i, '').replace(/[–—]/g, '-') !== '3-4') continue;
    // The mock tags Q24 as reasoning; balance scales are taught in the number lessons.
    const courseKey = Number(question.id) === 24 ? 'numbers' : module.key;
    if (!groups.has(courseKey)) groups.set(courseKey, []);
    groups.get(courseKey).push(question.id);
  }

  return [...groups.entries()].map(([courseKey, questionIds]) => {
    const course = MODULES[courseKey];
    if (!course?.lessons) return '';
    const questions = questionReferences(questionIds);
    const lessonText = lessons => t('program.lessons', { lessons }, `Lessons ${lessons}`);
    let lessons;
    if (enrolled && course.lessons.top5 !== course.lessons.top20) {
      lessons = `Top 5 Elite: ${lessonText(course.lessons.top5)}; Top 20 Mastery: ${lessonText(course.lessons.top20)}`;
    } else {
      lessons = lessonText(course.lessons[top5 ? 'top5' : 'top20']);
    }
    return `<li><strong class="module-name">${escapeHTML(moduleName(courseKey, course.name))}</strong> · ${escapeHTML(lessons)} <span class="class-review-questions">(${questions})</span></li>`;
  }).filter(Boolean).join('');
}

/** A compact topic-by-topic plan shared by enrolled and prospective students. */
export function renderPracticeModules({ questions = [], wrongQuestionIds = [], enrolled = false, top5 = false, includeCourseReferences = true } = {}) {
  const resolvedQuestions = questions;
  const selected = selectPracticeModules(resolvedQuestions, wrongQuestionIds);
  if (!selected.length) return '';

  return `<div class="practice-modules">${selected.map((module, index) => {
    const references = includeCourseReferences ? courseReferences(module, enrolled, top5) : '';
    const topics = groupMissedTopics(module.missedQuestions);
    if (!enrolled) {
      return `<article class="practice-module-card personalized-plan-card" data-practice-module="${escapeHTML(module.key)}">
        <header class="practice-module-header">
          <span class="practice-module-number" aria-hidden="true">${String(index + 1).padStart(2, '0')}</span>
          <h3>${escapeHTML(module.name)}</h3>
        </header>
        <div class="mock-evidence">
          <div class="plan-stage-heading"><h4>${escapeHTML(t('practice-plan.from-this-mock', {}, 'From this mock'))}</h4><span class="mock-missed-count">${escapeHTML(t('practice-plan.missed-count', { missed: module.missedCount, total: module.assessedCount }, `${module.missedCount} of ${module.assessedCount} missed`))}</span></div>
          <ul>${topics.map(topic => `<li><span class="practice-question">${questionReferences(topic.questionIds)}</span><strong>${escapeHTML(topic.topic)}</strong></li>`).join('')}</ul>
        </div>
        <div class="practice-actions">
          <h4>${escapeHTML(t('common.practice-next', {}, 'Practice next'))}</h4>
          <ul>${topics.map(topic => `<li><span class="practice-question">${questionReferences(topic.questionIds)}</span><div class="practice-guidance">${topic.guidance.map(guidance => `<p>${escapeHTML(guidance)}</p>`).join('')}</div></li>`).join('')}</ul>
        </div>
        ${references ? `<div class="class-review"><h4>${escapeHTML(t('practice-plan.covered-in-class', {}, 'Covered in class'))}</h4><ul>${references}</ul></div>` : ''}
      </article>`;
    }
    return `<article class="practice-module-card" data-practice-module="${escapeHTML(module.key)}">
      <header class="practice-module-header">
        <span class="practice-module-number" aria-hidden="true">${String(index + 1).padStart(2, '0')}</span>
        <h3>${escapeHTML(module.name)}</h3>
        <span class="practice-module-count">${escapeHTML(t(`practice-plan.review-count.${module.missedCount === 1 ? 'one' : 'other'}`, { count: module.missedCount }, `${module.missedCount} ${module.missedCount === 1 ? 'question' : 'questions'} to review`))}</span>
      </header>
      <ul class="practice-topics">${topics.map(topic => `<li class="practice-topic">
        <div class="practice-topic-heading"><span class="practice-question">${questionReferences(topic.questionIds)}</span><h4>${escapeHTML(topic.topic)}</h4></div>
        ${topic.guidance.map(guidance => `<p>${escapeHTML(guidance)}</p>`).join('')}
      </li>`).join('')}</ul>
      ${references ? `<div class="class-review"><h4>${escapeHTML(t('practice-plan.class-material-to-review', {}, 'Class Material to Review'))}</h4><ul>${references}</ul></div>` : ''}
    </article>`;
  }).join('')}</div>`;
}
