import { analysisText } from './i18n.js';

export function pointValueGroup(bands) {
  if (bands.length !== 3 || bands.some(band => !(band.total > 0))) return 'fallback';
  const [three, four, five] = bands.map(band => band.correct / band.total * 100);
  if ([three, four, five].every(rate => rate < 50)) return 't1';
  if ([three, four].every(rate => rate >= 50 && rate <= 80) && five < 50) return 't2';
  if ([three, four].every(rate => rate < 50) && five > 50) return 't3';
  if ([three, four].every(rate => rate > 80) && five > 50) return 't4';
  return 'fallback';
}

export function pointValueAnalysis(bands, level) {
  return analysisText(`point-value-analysis.${pointValueGroup(bands)}`, {},
    'Review the missed questions by point value, then practice similar questions independently.', level);
}

export function composeModuleSummary(results, level) {
  const assessed = results.filter(result => result.total > 0);
  if (!assessed.length) return { groups: { strengths: [], developing: [], priority: [] }, text: analysisText('module-summary.empty', {}, 'No module results are available for this test.', level) };
  const groups = { strengths: [], developing: [], priority: [] };
  for (const result of assessed) {
    const rate = result.correct / result.total * 100;
    groups[rate > 90 ? 'strengths' : rate >= 60 ? 'developing' : 'priority'].push(result.name);
  }
  const defaults = {
    strengths: 'Strong results in {module_names}. Maintain these skills with mixed practice.',
    developing: 'Build more consistent results in {module_names}. Revisit the missed topics, then practice similar questions.',
    priority: 'Start with {module_names}. Review the key ideas step by step, then retry the missed questions.'
  };
  const sentence = group => {
    if (!groups[group].length) return '';
    const names = groups[group].join(', ');
    return analysisText(`module-summary.${group}`, { module_names: names }, defaults[group].replace('{module_names}', names), level);
  };
  const parts = {
    strength_summary: sentence('strengths'),
    developing_summary: sentence('developing'),
    priority_summary: sentence('priority')
  };
  return { groups, text: analysisText('module-summary', parts, Object.values(parts).filter(Boolean).join(' '), level).trim().replace(/\s+/g, ' ') };
}
