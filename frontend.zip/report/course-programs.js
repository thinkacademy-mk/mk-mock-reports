// Course facts: 2027 MK Class FAQ pp. 1–2; Level 1–2 brochure;
// Level 5–6 Parent Meeting p. 6. Keep course modules separate from mock tags.
export const coursePrograms = {
  "1-2": {
    "lessons": 24,
    "minutes": 75,
    "modules": [
      { "key": "geometry", "name": "Geometry" },
      { "key": "numbers", "name": "Numbers & Operations" },
      { "key": "counting", "name": "Counting, Probability & Statistics" },
      { "key": "word", "name": "Word Problems" },
      { "key": "logic", "name": "Logical Reasoning" }
    ]
  },
  "3-4": {
    "lessons": 24,
    "minutes": 90,
    "modules": [
      { "key": "geometry", "name": "Geometry" },
      { "key": "numbers", "name": "Numbers & Operations" },
      { "key": "number-theory", "name": "Number Theory" },
      { "key": "word", "name": "Word Problems" },
      { "key": "counting", "name": "Counting, Probability & Statistics" },
      { "key": "logic", "name": "Logical Reasoning" }
    ]
  },
  "5-6": {
    "lessons": 24,
    "minutes": 90,
    "modules": [
      { "key": "geometry", "name": "Geometry" },
      { "key": "numbers", "name": "Numbers & Operations" },
      { "key": "data-statistics", "name": "Data & Statistics" },
      { "key": "word", "name": "Word Problems" },
      { "key": "logic", "name": "Logical Reasoning" },
      { "key": "number-theory", "name": "Number Theory" },
      { "key": "algebra-sequences", "name": "Algebra & Sequences" }
    ]
  }
};
