import { t } from './i18n.js';

export const goalCopyDefaults = {
  'nextstep.where-title': 'Where am I?',
  'nextstep.next-title': 'What’s the next step?',
  'nextstep.distance-title': 'How far from my goal?',
  'nextstep.reference-score': 'Suggested score: {reference_score}+',
  'nextstep.profile-score': '{goal} target profile · {profile_score} / {maximum}',
  'nextstep.points-to-go': '{points_to_gain} points to go',
  'nextstep.profile-achieved': 'Target profile achieved',
  'nextstep.point-gain': '+{points} points',
  'nextstep.target-count': 'Target: {target}/{total} correct',
  'nextstep.task.one': '{count} more {points}-point question',
  'nextstep.task.other': '{count} more {points}-point questions',
  'nextstep.list-join': '{first} and {last}',
  'nextstep.band-name': '{points}-point',
  'nextstep.where.perfect-title': 'Perfect score achieved',
  'nextstep.where.perfect-body': 'All {question_count} questions correct.',
  'nextstep.where.achieved-title': 'Target profile achieved',
  'nextstep.where.achieved-body': 'Your results meet all three {goal} targets.',
  'nextstep.where.foundation-secured-title': 'Foundation secured',
  'nextstep.where.foundation-secured-body': 'All 3- and 4-point questions correct. The remaining gap is in 5-point questions.',
  'nextstep.where.strong-foundation-title': 'Strong foundation',
  'nextstep.where.strong-foundation-body': 'All {total} three-point questions correct; {four_correct}/{total} four-point answers correct.',
  'nextstep.where.two-met-title': 'Two targets already met',
  'nextstep.where.two-met-body': 'Your {met_bands} results already meet the {goal} targets.',
  'nextstep.where.one-met-title': 'One target already met',
  'nextstep.where.one-met-body': 'Your {met_bands} results already meet the {goal} target. Build consistency in the other two sets.',
  'nextstep.where.building-title': 'Build a reliable foundation',
  'nextstep.where.building-body': 'Start by making your 3- and 4-point answers more reliable.',
  'nextstep.next.perfect-title': 'Maintain your perfect score',
  'nextstep.next.perfect-body': 'Keep a steady practice pace and aim to repeat this result in the next mock.',
  'nextstep.next.maintain-title': 'Keep it consistent',
  'nextstep.next.maintain-body': 'Use mixed practice and aim to repeat this level in the next mock.',
  'nextstep.next.five-point-title': 'Push 5-point accuracy',
  'nextstep.next.four-point-title': 'Complete the 4-point set',
  'nextstep.next.three-point-title': 'Complete the 3-point set',
  'nextstep.next.foundation-title': 'Secure the foundation, then build up',
  'nextstep.next.task-body': 'Answer {remaining_tasks} correctly to complete this profile.'
};

export const goalText = (key, variables = {}) => t(key, variables, goalCopyDefaults[key] ?? '');

function joinItems(items) {
  if (items.length < 2) return items[0] ?? '';
  return goalText('nextstep.list-join', { first: items.slice(0, -1).join(', '), last: items.at(-1) });
}

export function goalNarrative(plan) {
  const variables = {
    goal: plan.title, total: plan.total, four_correct: plan.bands[1],
    question_count: plan.total * 3,
    met_bands: joinItems(plan.metBands.map(points => goalText('nextstep.band-name', { points }))),
    remaining_tasks: joinItems(plan.remaining.flatMap((count, index) => count
      ? [goalText(`nextstep.task.${count === 1 ? 'one' : 'other'}`, { count, points: index + 3 })]
      : []))
  };
  return {
    whereTitle: goalText(`nextstep.where.${plan.whereState}-title`, variables),
    whereBody: goalText(`nextstep.where.${plan.whereState}-body`, variables),
    nextTitle: goalText(`nextstep.next.${plan.nextState}-title`, variables),
    nextBody: goalText(['perfect', 'maintain'].includes(plan.nextState)
      ? `nextstep.next.${plan.nextState}-body` : 'nextstep.next.task-body', variables)
  };
}
