import { t } from './i18n.js';

// Default guidance belongs to this Level 3–4 paper. Other levels use their own sheet rows.
const LEVEL_34_GUIDANCE = {
  1: 'Identify the edges and corners that must connect before completing a hidden shape.',
  2: 'Apply the order of operations and record each calculation step.',
  3: 'Compare shape attributes and check each code against every condition.',
  4: 'Track a marked point through each rotation to keep relative positions consistent.',
  5: 'Compare packing arrangements and check that fewer boxes cannot hold all the items.',
  6: 'Count cubes by layers and include cubes hidden behind the visible faces.',
  7: 'Track the starting direction and update it after each rotation.',
  8: 'Trace each boundary carefully to decide which regions are enclosed.',
  9: 'Use the number eaten each day to identify which day includes the numbered nut. Place the known weekday on a timeline, then work backward to the first day.',
  10: 'Reflect the cells across the fold line and compare each matching pair. Track how black and transparent squares overlap after folding.',
  11: 'List the fruits available in each container and begin with the most restricted choices. Check that the final selection uses one fruit from each container and five different fruits.',
  12: 'Record each turn in order and check the final direction against the rules.',
  13: 'Compare tile edges and areas to test whether the pieces form the required shape.',
  14: 'Trace the outside boundary and separate it from internal edges before calculating perimeter.',
  15: 'Try each tile orientation systematically and check whether all edges can fit.',
  16: 'Convert each Roman numeral carefully before comparing or calculating.',
  17: 'Compare the total weights for the two amounts of water. Use the change in the number of cups to separate the water weight from the empty bottle weight.',
  18: 'Place confirmed positions first, then check each ordering condition.',
  19: 'Track how every person\'s age changes over the same number of years. Keep the age-sum relationship and the consecutive-age relationship separate before combining them.',
  20: 'Represent the quantities in a diagram before comparing possible distributions.',
  21: 'Test each statement against the others and reject any case that creates a contradiction.',
  22: 'Mark one full back-and-forth cycle before finding the requested position.',
  23: 'Split the solid into front and back layers, then record the known colored cubes in each layer. Use the remaining positions to reconstruct the connected red-cube shape.',
  24: 'Record each balance condition as an equality or a comparison. Compare the possible weights systematically, then check each possibility against all the conditions.'
};

const normalize = value => String(value ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLowerCase();
const MODULE_ALIASES = new Map([
  ['geometry', 'geometry'], ['几何', 'geometry'], ['幾何', 'geometry'],
  ['numbers', 'numbers'], ['numbers & operations', 'numbers'], ['numbers and operations', 'numbers'], ['数与运算', 'numbers'], ['數與運算', 'numbers'],
  ['word', 'word'], ['word problems', 'word'], ['应用题', 'word'], ['應用題', 'word'],
  ['logic', 'logic'], ['logical reasoning', 'logic'], ['逻辑推理', 'logic'], ['邏輯推理', 'logic']
]);

/** Resolve only this level's question copy; a blank cell preserves the paper's default. */
export function resolveQuestionContent(question, level = '3-4') {
  const resolvedLevel = String(level).trim().replace(/^lv/i, '').replace(/[–—]/g, '-');
  const originalModule = MODULE_ALIASES.get(normalize(question.module)) ?? question.module;
  const fallbackGuidance = String(question.guidance ?? '').trim()
    || (resolvedLevel === '3-4' ? LEVEL_34_GUIDANCE[question.id] ?? '' : '');
  const result = { ...question, module: originalModule, topic: question.topic ?? '', guidance: fallbackGuidance };
  if (!/^(1-2|3-4|5-6)$/.test(resolvedLevel) || !/^\d+$/.test(String(question.id))) return result;

  const questionCopy = t(`score-breakdown.lv${resolvedLevel}.q${question.id}`, {}, '').trim();
  if (questionCopy) {
    const separator = questionCopy.search(/[;；]/);
    if (separator !== -1) {
      const knownModule = MODULE_ALIASES.get(normalize(questionCopy.slice(0, separator)));
      if (knownModule) result.module = knownModule;
      const topic = questionCopy.slice(separator + 1).trim();
      if (topic) result.topic = topic;
    } else {
      const knownModule = MODULE_ALIASES.get(normalize(questionCopy));
      if (knownModule) result.module = knownModule;
      else result.topic = questionCopy;
    }
  }
  result.guidance = t(`module-analysis.lv${resolvedLevel}.question-analysis.q${question.id}`, {}, fallbackGuidance).trim() || fallbackGuidance;
  return result;
}
