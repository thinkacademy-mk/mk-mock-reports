import { copyMessages } from './i18n-data.js';

export const REPORT_LEVEL = '3-4';

export function hasCopy(key) {
  return typeof copyMessages[key] === 'string' && copyMessages[key].trim().length > 0;
}

export function t(key, variables = {}, fallback = '') {
  const template = hasCopy(key) ? copyMessages[key] : fallback;
  return String(template).replace(/\{([a-z_]+)\}/g, (token, name) =>
    Object.hasOwn(variables, name) ? String(variables[name] ?? '') : token);
}

export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[character]));

const moduleKeys = {
  geometry: ['geometry', 'Geometry'],
  numbers: ['numbers-operations', 'Numbers & Operations'],
  word: ['word-problems', 'Word Problems'],
  logic: ['logical-reasoning', 'Logical Reasoning'],
  'number-theory': ['number-theory', 'Number Theory'],
  counting: ['counting-probability-statistics', 'Counting, Probability & Statistics'],
  'numbers-patterns': ['numbers-operations-patterns', 'Numbers, Operations & Patterns']
};

export function moduleName(key, fallback = '') {
  const [suffix, original] = moduleKeys[key] ?? [key, key];
  return t(`module-name.${suffix}`, {}, fallback || original);
}

// These entries were explicitly authored as shared prose in the Sheet. Only
// this allowlist may reuse its legacy lv1-2 key; question data stays level-specific.
const sharedAnalysisKeys = {
  ...Object.fromEntries(['t1', 't2', 't3', 't4', 'fallback'].map(type =>
    [`point-value-analysis.${type}`, `score-breakdown.lv1-2.point-value-analysis.${type}`])),
  ...Object.fromEntries(['', '.strengths', '.developing', '.priority', '.empty'].map(suffix =>
    [`module-summary${suffix}`, `score-breakdown.lv1-2.module-summary${suffix}`])),
  ...Object.fromEntries(['geometry', 'numbers&operations', 'wordproblems', 'reasoning'].map(module =>
    [`module-intro.${module}`, `module-analysis.lv1-2.module-summary.${module}`]))
};

export function analysisText(name, variables = {}, fallback = '', level = REPORT_LEVEL) {
  const sharedKey = sharedAnalysisKeys[name];
  if (!sharedKey) return fallback;
  const levelKey = sharedKey.replace('.lv1-2.', `.lv${level}.`);
  return t(hasCopy(levelKey) ? levelKey : sharedKey, variables, fallback);
}
