'use strict';

import { loadReport } from './report-loader.js';
import { goalGradeFor, localAssetURL, reportDestination, MODULES } from '../lookup-model.mjs';
import { renderNextStepsView } from './next-step.js';
import { t, moduleName, escapeHTML } from './i18n.js';
import { composeModuleSummary, pointValueAnalysis } from './report-copy.js';

const report = await loadReport();
const siteRoot = new URL('../', import.meta.url);
const questions = [...report.questions].sort((a, b) => a.id - b.id).map(question => ({ ...question, level: report.level }));
const correctIds = new Set(report.correctQuestionIds);
const wrongIds = new Set(report.wrongQuestionIds);
const $ = id => document.getElementById(id);
const percentage = (part, total) => `${(part / total * 100).toFixed(1)}%`;
const unavailable = () => t('common.not-available', {}, 'Not available');
const levelLabel = `Level ${report.level.replace('-', '–')}`;
const moduleKeys = MODULES.filter(key => questions.some(question => question.module === key));
const nameFor = key => moduleName(key, report.moduleOverview?.[key]?.name ?? '');
let imageTrigger = null;

function metrics(items) {
  const correct = items.filter(question => correctIds.has(question.id));
  const maximum = items.reduce((sum, question) => sum + question.points, 0);
  const score = correct.reduce((sum, question) => sum + question.points, 0);
  return { total: items.length, correct: correct.length, maximum, score, rate: percentage(correct.length, items.length) };
}

function dateLabel(value) {
  if (typeof value !== 'string' || !value.trim()) return unavailable();
  const match = /^(\d{4}-\d{2}-\d{2})/.exec(value);
  if (!match) return value;
  const date = new Date(`${match[1]}T12:00:00Z`);
  return Number.isNaN(date.valueOf()) ? unavailable() : new Intl.DateTimeFormat('en-US', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' }).format(date);
}

function renderHeader() {
  $('report-edition-label').textContent = `MOCK TEST 01 · ${levelLabel.toUpperCase()}`;
  $('footer-edition').textContent = `${levelLabel} · Mock Test 01`;
  const identity = document.querySelector('.student-information');
  const fields = [['Name', `${report.firstName} ${report.lastName}`.trim()], ['Student ID', report.studentNumber], ['Test date', dateLabel(report.date)]];
  if (report.gradeLabel) fields.push(['Grade', String(report.gradeLabel)]);
  identity.replaceChildren(...fields.map(([label, value]) => {
    const item = document.createElement('span');
    const heading = document.createElement('b');
    heading.textContent = label;
    item.append(heading, ` ${value}`);
    return item;
  }));
  const levels = $('report-levels');
  levels.hidden = report.availableLevels.length < 2;
  for (const level of report.availableLevels) {
    const link = document.createElement('a');
    link.href = reportDestination({ level }, report.token, siteRoot).href;
    link.textContent = `Level ${level.replace('-', '–')}`;
    if (level === report.level) link.setAttribute('aria-current', 'page');
    levels.append(link);
  }
  if (report.pdfPath) {
    const link = $('download-pdf');
    link.href = localAssetURL(report.pdfPath, siteRoot, 'pdf').href;
    link.download = `Math-Kangaroo-Mock-1-Level-${report.level}.pdf`;
    link.hidden = false;
  }
}

function renderOverview() {
  const result = metrics(questions);
  const rank = Number.isInteger(report.rank) && report.rank > 0 ? String(report.rank) : unavailable();
  const percentile = Number.isFinite(report.percentile) && report.percentile >= 0 && report.percentile <= 100 ? `${report.percentile.toFixed(1)}%` : unavailable();
  $('overview-body').innerHTML = `<tr><td>${escapeHTML(report.firstName)}</td><td>${escapeHTML(report.lastName)}</td><td>${escapeHTML(report.studentNumber)}</td><td>${escapeHTML(report.level.replace('-', '–'))}</td><td>Think Academy Online</td><td class="score-cell">${result.score} / ${report.maximum}</td><td>${percentage(result.score, result.maximum)}</td><td>${escapeHTML(rank)}</td><td>${escapeHTML(percentile)}</td></tr>`;
  const cohort = report.cohortLabel || levelLabel;
  $('cohort-note').textContent = Number.isInteger(report.cohortSize) && report.cohortSize > 0
    ? `Mock 1 results · ${report.cohortSize} participants · ${cohort}.`
    : '';
  if (report.rankingBasis === 'level-and-grade') {
    const definitions = document.querySelectorAll('.metric-definitions li');
    definitions[2].innerHTML = '<strong>Place:</strong> The student’s rank among participants with the same test level and recorded grade.';
    definitions[3].innerHTML = '<strong>Percentile:</strong> The percentage of participants with the same test level and recorded grade who scored lower.';
  }
}

function renderScoreBreakdown() {
  const tables = {3:'three-point-body',4:'four-point-body',5:'five-point-body'};
  for (const points of [3,4,5]) {
    $(tables[points]).innerHTML = questions.filter(question => question.points === points).map(question => {
      const wrong = wrongIds.has(question.id);
      const status = t(wrong ? 'common.incorrect' : 'common.correct', {}, wrong ? 'Incorrect' : 'Correct');
      return `<tr><td>${question.id}</td><td><strong class="module-name">${escapeHTML(nameFor(question.module))}</strong></td><td>${escapeHTML(question.topic)}</td><td class="result-cell"><span class="${wrong ? 'result-wrong' : 'result-correct'}" role="img" aria-label="${escapeHTML(status)}">${wrong ? '×' : '✓'}</span></td></tr>`;
    }).join('');
  }
  const bands = [3,4,5].map(points => ({points,...metrics(questions.filter(question => question.points === points))}));
  $('level-rates-body').innerHTML = bands.map(result => `<tr><th scope="row">${result.points}-point</th><td>${result.correct} / ${result.total}</td><td>${result.score} / ${result.maximum}</td><td>${result.rate}</td></tr>`).join('');
  $('band-commentary').textContent = pointValueAnalysis(bands, report.level);
}

function renderModuleRates() {
  const results = moduleKeys.map(key => ({ key, name:nameFor(key), ...metrics(questions.filter(question => question.module === key)) }));
  $('module-rates-body').innerHTML = results.map(result => `<tr><th scope="row">${escapeHTML(result.name)}</th><td>${result.total}</td><td>${result.correct}</td><td>${result.score} / ${result.maximum}</td><td>${result.rate}</td></tr>`).join('');
  const summary = composeModuleSummary(results, report.level);
  $('module-commentary').innerHTML = `<p class="module-summary-item">${escapeHTML(summary.text)}</p>${report.level === '3-4' ? '<p class="history-method-note">Source: 2012–2026 Level 3–4 papers, 360 questions. Topics may overlap.</p>' : ''}`;
}

function wrongQuestionTable(moduleKey) {
  const missed = questions.filter(question => question.module === moduleKey && wrongIds.has(question.id));
  if (!missed.length) return '';
  const count = `${missed.length} ${missed.length === 1 ? 'question' : 'questions'}`;
  return `<details class="wrong-question-panel"><summary class="wrong-list-title">${escapeHTML(t('module-analysis.questions-to-review', {}, 'Questions to Review'))} <span class="review-count">${count}</span><span class="review-chevron" aria-hidden="true">⌄</span></summary><div class="table-scroll"><table class="wrong-question-table"><thead><tr><th scope="col">#</th><th scope="col">${escapeHTML(t('common.question', {}, 'Question'))}</th><th scope="col">${escapeHTML(t('common.key-topic', {}, 'Key Topic'))}</th></tr></thead><tbody>${missed.map(question => `<tr><td>Q${question.id}<small>${question.points} points</small></td><td>${question.image ? `<button type="button" class="question-image-button" data-image="${question.id}" aria-label="View full question image for Question ${question.id}"><img src="${escapeHTML(localAssetURL(question.image,siteRoot,'image').href)}" alt="Question ${question.id}: ${escapeHTML(question.topic)}. Original question with all options." loading="lazy" width="1270"></button>` : ''}</td><td><strong>${escapeHTML(question.topic)}</strong><p>${escapeHTML(question.guidance)}</p></td></tr>`).join('')}</tbody></table></div></details>`;
}

function moduleDescription(key) {
  const entry = report.moduleOverview?.[key];
  const description = typeof entry === 'string' ? entry : entry?.description ?? '';
  const name = `<strong class="module-name">${escapeHTML(nameFor(key))}</strong>`;
  if (report.level !== '3-4') return `${name}. ${escapeHTML(description)}`;
  const history = {geometry:'30.3',numbers:'16.1',word:'21.9',logic:'22.5'}[key];
  if (!history) return `${name}. ${escapeHTML(description)}`;
  if (key === 'geometry') return `${name} is the most frequently tested module in Math Kangaroo Level 3–4 over the past 15 years, appearing in <span class="history-stat">30.3% of questions</span>—almost one in three. ${escapeHTML(description)}`;
  return `${name} appeared in <span class="history-stat">${history}% of questions</span> from the past 15 years of Math Kangaroo Level 3–4 papers. ${escapeHTML(description)}`;
}

function renderModuleAnalysis() {
  $('modules-content').innerHTML = moduleKeys.map(key => {
    const assessed = questions.filter(question => question.module === key);
    const result = metrics(assessed);
    const missed = assessed.filter(question => wrongIds.has(question.id));
    const correct = assessed.filter(question => correctIds.has(question.id));
    const topicList = items => items.map(question => `${escapeHTML(question.topic)} (Q${question.id})`).join('; ');
    return `<article class="module-card"><header class="module-header"><h3>${escapeHTML(nameFor(key))}</h3><span class="module-stat">${result.correct} / ${result.total} correct · ${result.rate}</span></header><p class="module-importance">${moduleDescription(key)}</p><ul class="module-notes">${correct.length ? `<li><strong>${escapeHTML(t('module-analysis.strengths', {}, 'Strengths'))}:</strong> ${topicList(correct)}</li>` : ''}${missed.length ? `<li><strong>${escapeHTML(t('common.practice-next', {}, 'Practice next'))}:</strong> ${topicList(missed)}</li>` : ''}</ul>${wrongQuestionTable(key)}</article>`;
  }).join('');
  document.querySelectorAll('[data-image]').forEach(button => button.addEventListener('click', () => {
    const question = questions.find(item => item.id === Number(button.dataset.image));
    openImage(button, `Question ${question.id}`, localAssetURL(question.image,siteRoot,'image').href, `Question ${question.id}: ${question.topic}`, 'Original mock test question.');
  }));
}

function openImage(trigger, title, src, alt, caption) {
  imageTrigger = trigger;
  $('image-dialog-title').textContent = title;
  $('expanded-question').src = src;
  $('expanded-question').alt = alt;
  $('image-dialog-caption').textContent = caption;
  $('image-dialog').showModal();
}

function renderNextSteps() {
  $('next-step').dataset.reportType = report.audience === 'new' ? 'conversion' : 'learning';
  renderNextStepsView({ host:$('next-step-content'), score:report.score,
    bands:[3,4,5].map(points => metrics(questions.filter(question => question.points === points)).correct),
    enrolled:report.audience === 'enrolled', audience:report.audience,
    studentName:report.firstName, grade:goalGradeFor(report.level), level:report.level,
    questions, wrongQuestionIds:report.wrongQuestionIds });
  document.querySelectorAll('[data-material-src]').forEach(button => button.addEventListener('click', () => openImage(button,button.dataset.materialTitle,button.dataset.materialSrc,button.dataset.materialTitle,'Original Think Academy course material.')));
}

function applyStaticCopy() {
  const variables = { question_count:questions.length, points:report.maximum };
  document.querySelectorAll('[data-i18n]').forEach(node => {
    if (node.dataset.i18n === 'score-breakdown.summary') node.textContent = `${questions.length} questions · ${report.maximum} points`;
    else node.textContent = t(node.dataset.i18n, variables, node.textContent.replace(/:$/, '')) + (node.dataset.i18nSuffix ?? '');
  });
  document.title = `${t('report.title', {}, 'Math Kangaroo Mock Test Report')} · ${levelLabel} | Think Academy`;
}

document.querySelectorAll('[data-close-image]').forEach(button => button.addEventListener('click', () => $('image-dialog').close()));
$('image-dialog').addEventListener('close', () => { if (imageTrigger?.isConnected) imageTrigger.focus(); imageTrigger = null; });
$('image-dialog').addEventListener('click', event => {
  if (event.target !== $('image-dialog')) return;
  const bounds = $('image-dialog').getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) $('image-dialog').close();
});
applyStaticCopy();
renderHeader();
renderOverview();
renderScoreBreakdown();
renderModuleRates();
renderModuleAnalysis();
renderNextSteps();
const cleanURL = new URL(location.href);
for (const key of ['audience','score','preview','sample']) cleanURL.searchParams.delete(key);
cleanURL.searchParams.set('level',report.level);
history.replaceState({},'',cleanURL);
