export const LEVELS = ['1-2', '3-4', '5-6'];
export const MODULES = ['geometry', 'numbers', 'number-theory', 'word', 'counting', 'logic'];
const TOKEN = /^[a-f0-9]{32}$/;
const STUDENT_NUMBER = /^\d{12}$/;

export const isStudentNumber = value => typeof value === 'string' && STUDENT_NUMBER.test(value);
export const isReportToken = value => typeof value === 'string' && TOKEN.test(value);
export const goalGradeFor = level => level === '5-6' ? 5 : level === '3-4' ? 3 : 1;

export async function reportTokenFor(studentNumber, cryptoProvider = globalThis.crypto) {
  if (!isStudentNumber(studentNumber)) throw new TypeError('Invalid Student Number');
  if (!cryptoProvider?.subtle) throw new Error('Secure browser required');
  const digest = await cryptoProvider.subtle.digest('SHA-256', new TextEncoder().encode(`mk-mock1:${studentNumber}`));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('').slice(0, 32);
}

export function localAssetURL(relativePath, siteRoot, kind) {
  if (typeof relativePath !== 'string' || relativePath.includes('\\') || relativePath.split('/').some(part => part === '..' || part === '.')) throw new TypeError('Invalid asset path');
  const expression = kind === 'pdf'
    ? /^pdfs\/(?:[A-Za-z0-9_-]+\/)*[A-Za-z0-9_.-]+\.pdf$/
    : /^assets\/level-(?:1-2|3-4|5-6)\/[A-Za-z0-9_.-]+\.(?:png|jpg|jpeg|webp|svg)$/;
  if (!expression.test(relativePath)) throw new TypeError('Invalid asset path');
  const root = new URL(siteRoot);
  const destination = new URL(relativePath, root);
  if (destination.origin !== root.origin || !destination.pathname.startsWith(root.pathname)) throw new TypeError('Invalid asset origin');
  return destination;
}

function questionIds(value, expectedCount) {
  if (!Array.isArray(value) || value.some(id => !Number.isInteger(id) || id < 1 || id > expectedCount) || new Set(value).size !== value.length) throw new TypeError('Invalid question results');
  return new Set(value);
}

export function validateReport(report) {
  if (!report || typeof report !== 'object' || Array.isArray(report) || !LEVELS.includes(report.level) ||
      !['new', 'enrolled', 'unknown'].includes(report.audience) || typeof report.firstName !== 'string' || typeof report.lastName !== 'string' ||
      !Array.isArray(report.questions)) throw new TypeError('Invalid report');
  const expectedAudience = { 'confirmed-mk': 'enrolled', 'no-confirmed-mk': 'new', unverified: 'unknown' }[report.enrollmentStatus];
  if (!expectedAudience || expectedAudience !== report.audience) throw new TypeError('Invalid enrollment status');
  const total = report.level === '5-6' ? 30 : 24;
  const maximum = report.level === '5-6' ? 120 : 96;
  if (report.questions.length !== total || report.maximum !== maximum || !Number.isInteger(report.score) || report.score < 0 || report.score > maximum) throw new TypeError('Invalid score profile');
  const ids = new Set();
  const bands = {3:0,4:0,5:0};
  for (const question of report.questions) {
    if (!question || !Number.isInteger(question.id) || question.id < 1 || question.id > total || ids.has(question.id) ||
        ![3,4,5].includes(question.points) || !MODULES.includes(question.module) ||
        typeof question.topic !== 'string' || typeof question.guidance !== 'string') throw new TypeError('Invalid question');
    if (question.image) localAssetURL(question.image, 'https://report.invalid/', 'image');
    ids.add(question.id);
    bands[question.points] += 1;
  }
  if (Object.values(bands).some(count => count !== total / 3)) throw new TypeError('Invalid point bands');
  const correct = questionIds(report.correctQuestionIds, total);
  const wrong = questionIds(report.wrongQuestionIds, total);
  if (correct.size + wrong.size !== total || [...correct].some(id => wrong.has(id))) throw new TypeError('Incomplete question results');
  const earned = report.questions.reduce((sum, question) => sum + (correct.has(question.id) ? question.points : 0), 0);
  if (earned !== report.score) throw new TypeError('Score does not match question results');
  if (report.pdfPath) localAssetURL(report.pdfPath, 'https://report.invalid/', 'pdf');
  return report;
}

export async function validateStudentRecord(payload, { studentNumber, token } = {}) {
  if (!payload || typeof payload !== 'object' || Array.isArray(payload) || payload.schemaVersion !== 2 ||
      payload.reportType !== 'mk-mock-report' || !isStudentNumber(payload.studentNumber) || payload.previewOnly === true ||
      !Array.isArray(payload.reports) || !payload.reports.length || payload.reports.length > LEVELS.length ||
      (studentNumber !== undefined && payload.studentNumber !== studentNumber)) throw new TypeError('Invalid student record');
  const computed = await reportTokenFor(payload.studentNumber);
  if (token !== undefined && (!isReportToken(token) || computed !== token)) throw new TypeError('Report identity mismatch');
  const levels = new Set();
  for (const report of payload.reports) {
    validateReport(report);
    if (levels.has(report.level)) throw new TypeError('Duplicate report level');
    levels.add(report.level);
  }
  return payload;
}

export function reportDestination(report, token, siteRoot) {
  if (!LEVELS.includes(report?.level) || !isReportToken(token)) throw new TypeError('Invalid report destination');
  const destination = new URL('report/', siteRoot);
  destination.searchParams.set('report', token);
  destination.searchParams.set('level', report.level);
  return destination;
}
