/** Approved report-only telemetry. No storage, automatic page capture, or navigation interception. */
export const API_ORIGIN = 'https://thinkacademy-mk-reports.the-think-ac-1822.chatgpt.site';
export const TOKEN_ENDPOINT = `${API_ORIGIN}/api/mock-event-token`;
export const EVENT_ENDPOINT = `${API_ORIGIN}/api/mock-event`;
export const REPORT_KEY_PATTERN = /^[0-9a-f]{32}-(?:1-2|3-4|5-6)$/;
export const BUTTON_IDS = Object.freeze([
  'pdf_download', 'answer_sheet', 'group_wechat', 'group_whatsapp',
  'benefit_wechat', 'benefit_whatsapp', 'report_lookup', 'question_image',
]);
export const PLACEMENTS = Object.freeze([
  'page', 'header', 'review', 'question', 'top_qr', 'top_button',
  'middle_qr', 'middle_button', 'bottom_qr', 'bottom_button',
]);

function validClickPair(buttonId, placement) {
  if (buttonId === 'pdf_download' || buttonId === 'report_lookup') return placement === 'header';
  if (buttonId === 'answer_sheet') return placement === 'review';
  if (buttonId === 'question_image') return placement === 'question';
  if (buttonId.startsWith('group_')) return /^(?:top|bottom)_(?:qr|button)$/.test(placement);
  if (buttonId.startsWith('benefit_')) return /^(?:middle|bottom)_(?:qr|button)$/.test(placement);
  return false;
}

/** Classify the existing DOM without reading link URLs, labels, student fields or scores. */
export function classifyClick(target, doc) {
  const element = typeof target?.closest === 'function' ? target : target?.parentElement;
  const anchor = element?.closest?.('a');
  if (!anchor) return null;
  if (anchor.matches('.report-lookup-nav a.download-pdf')) return { buttonId: 'pdf_download', placement: 'header' };
  if (anchor.matches('.report-lookup-nav a:not(.download-pdf)')) return { buttonId: 'report_lookup', placement: 'header' };
  if (anchor.matches('.answer-sheet-link a')) return { buttonId: 'answer_sheet', placement: 'review' };
  if (anchor.matches('a.question-screenshot')) return { buttonId: 'question_image', placement: 'question' };

  const banner = anchor.closest('.contact-cta');
  const card = anchor.closest('.contact-card');
  if (!banner || !card) return null;
  const kind = banner.classList.contains('group-cta') ? 'group' : banner.classList.contains('benefit-cta') ? 'benefit' : null;
  const isQR = Boolean(anchor.querySelector('img'));
  if (!kind || (!isQR && !anchor.classList.contains('contact-button'))) return null;
  let channel = null;
  if (anchor.classList.contains('wechat') || (isQR && card.querySelector('a.contact-button.wechat'))) channel = 'wechat';
  else if (anchor.classList.contains('whatsapp') || (isQR && card.querySelector('a.contact-button.whatsapp'))) channel = 'whatsapp';
  if (!channel) return null;
  const banners = Array.from(doc.querySelectorAll('.contact-cta'));
  const index = banners.indexOf(banner);
  if (index < 0) return null;
  const position = index === 0 ? 'top' : index === banners.length - 1 ? 'bottom' : 'middle';
  const result = { buttonId: `${kind}_${channel}`, placement: `${position}_${isQR ? 'qr' : 'button'}` };
  return validClickPair(result.buttonId, result.placement) ? result : null;
}

function eventUUID(cryptoImpl) {
  if (typeof cryptoImpl?.randomUUID === 'function') return cryptoImpl.randomUUID();
  if (typeof cryptoImpl?.getRandomValues !== 'function') return null;
  const bytes = cryptoImpl.getRandomValues(new Uint8Array(16));
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = [...bytes].map(value => value.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

/** Dependencies are injectable for offline tests. Destinations and payload shape remain fixed. */
export function createMockTracker({ document: doc, reportKey, fetch: fetchImpl = globalThis.fetch, crypto: cryptoImpl = globalThis.crypto } = {}) {
  if (!doc || !REPORT_KEY_PATTERN.test(reportKey ?? '') || typeof fetchImpl !== 'function') return null;
  let started = false;
  let opened = false;

  async function send(payload) {
    // A single keepalive request survives navigation without waiting for a token round trip.
    await fetchImpl(EVENT_ENDPOINT, {
      method: 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store',
      referrerPolicy: 'no-referrer', keepalive: true,
      headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
    });
  }

  function emit(eventType, buttonId, placement) {
    if (eventType === 'report_open') {
      if (buttonId !== '' || placement !== 'page') return;
    } else if (eventType !== 'button_click' || !BUTTON_IDS.includes(buttonId) || !validClickPair(buttonId, placement)) return;
    try {
      const eventId = eventUUID(cryptoImpl);
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(eventId ?? '')) return;
      // Explicit construction prevents form fields, hrefs and document metadata leaking into events.
      void send({ eventId, reportKey, eventType, buttonId, placement }).catch(() => {});
    } catch {
      // Tracking is optional; network, UUID or browser failures must not affect report use.
    }
  }

  function checkVisible() {
    if (!started || opened || doc.prerendering || doc.visibilityState !== 'visible') return;
    opened = true;
    doc.removeEventListener('visibilitychange', checkVisible);
    doc.removeEventListener('prerenderingchange', checkVisible);
    emit('report_open', '', 'page');
  }

  function handleClick(event) {
    if (!started || event.isTrusted !== true || event.defaultPrevented) return;
    if (event.type === 'click' ? event.button !== 0 : event.type !== 'auxclick' || event.button !== 1) return;
    try {
      const target = classifyClick(event.target, doc);
      if (target) emit('button_click', target.buttonId, target.placement);
    } catch {
      // Never block a native click because optional telemetry could not classify it.
    }
  }

  return {
    start() {
      if (started) return;
      started = true;
      doc.addEventListener('click', handleClick, { capture: true, passive: true });
      doc.addEventListener('auxclick', handleClick, { capture: true, passive: true });
      doc.addEventListener('visibilitychange', checkVisible);
      doc.addEventListener('prerenderingchange', checkVisible);
      checkVisible();
    },
    stop() {
      started = false;
      doc.removeEventListener('click', handleClick, true);
      doc.removeEventListener('auxclick', handleClick, true);
      doc.removeEventListener('visibilitychange', checkVisible);
      doc.removeEventListener('prerenderingchange', checkVisible);
    },
  };
}

// A module does not have document.currentScript. Read only the explicit injected key attribute.
if (typeof document !== 'undefined') {
  try {
    const script = document.querySelector('script[data-mock-report-key]');
    const tracker = createMockTracker({ document, reportKey: script?.getAttribute('data-mock-report-key') });
    tracker?.start();
  } catch {
    // Analytics must never introduce a report-page startup error.
  }
}
